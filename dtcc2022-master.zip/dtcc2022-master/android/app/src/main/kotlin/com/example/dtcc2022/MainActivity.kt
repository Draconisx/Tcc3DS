package com.example.dtcc2022

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
